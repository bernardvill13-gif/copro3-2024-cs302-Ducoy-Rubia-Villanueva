﻿using System;

namespace Codes.AppSetting.AppInfo
{
    public struct AppInfoConfig
    {
        public static String NAME = "The Pathfinder’s Quest: The Book of Zephyro";
        public static String jl = "John Lloyd Ducoy";
        public static String jester = "Jester MALAKAS Rubia";
        public static String bernard = "Bernard Villanueva";

    }

}
